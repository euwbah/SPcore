## TODOs

- [ ] Lesson notification -> when time reach send json to firebase, so that user gets notification when lesson is 15 minute before it starts

