package models

data class StringResponse(val response: String)